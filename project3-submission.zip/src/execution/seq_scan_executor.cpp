//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// seq_scan_executor.cpp
//
// Identification: src/execution/seq_scan_executor.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "execution/executors/seq_scan_executor.h"

namespace bustub {

SeqScanExecutor::SeqScanExecutor(ExecutorContext *exec_ctx, const SeqScanPlanNode *plan) : AbstractExecutor(exec_ctx) {
  plan_ = plan;
  table_info_ = exec_ctx_->GetCatalog()->GetTable(plan_->GetTableOid());
  table_iterator_ = table_info_->table_->Begin(exec_ctx_->GetTransaction());
}

void SeqScanExecutor::Init() { table_iterator_ = table_info_->table_->Begin(exec_ctx_->GetTransaction()); }

bool SeqScanExecutor::Next(Tuple *tuple, RID *rid) {
  if (table_iterator_ == table_info_->table_->End()) {
    return false;
  }
  Tuple *cur_tuple = nullptr;
  while (plan_->GetPredicate() != nullptr &&
         !plan_->GetPredicate()->Evaluate(table_iterator_.operator->(), &table_info_->schema_).GetAs<bool>()) {
    ++table_iterator_;
    if (table_iterator_ == table_info_->table_->End()) {
      return false;
    }
  }
  cur_tuple = table_iterator_.operator->();
  std::vector<Value> values;
  for (auto &col : GetOutputSchema()->GetColumns()) {
    Value v = col.GetExpr()->Evaluate(cur_tuple, &(table_info_->schema_));
    values.push_back(v);
  }
  *tuple = Tuple(values, GetOutputSchema());
  *rid = cur_tuple->GetRid();
  ++table_iterator_;
  return true;
}

}  // namespace bustub
